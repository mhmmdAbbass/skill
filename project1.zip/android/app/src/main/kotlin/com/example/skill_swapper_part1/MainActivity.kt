package com.example.skill_swapper_part1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

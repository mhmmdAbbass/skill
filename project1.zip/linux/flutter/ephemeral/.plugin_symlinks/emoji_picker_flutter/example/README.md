# Examples

### Simple

Basic usage example

[Jump to Source](https://github.com/Fintasys/emoji_picker_flutter/tree/master/example/lib/main.dart)

### Custom Font

Example how to use EmojiPicker with custom font

[Jump to Source](https://github.com/Fintasys/emoji_picker_flutter/tree/master/example/lib/main-custom-font.dart)

### Search

Example how to use EmojiPicker with custom search field for emoji

[Jump to Source](https://github.com/Fintasys/emoji_picker_flutter/tree/master/example/lib/main-search.dart)
